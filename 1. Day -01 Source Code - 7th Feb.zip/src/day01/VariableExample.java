package day01;

public class VariableExample {

	//global variable 
	int g1 =100;			//instance variable
	static double d =1112.1;//static variable
	
	public static void main(String[] args) {
	
		//local variable 
		int x =100;		
		System.out.println(x);  //access to local variable
		
		//access to global variable
		System.out.println(d);   //access to global static variable 
		System.out.println(VariableExample.d); //or -access to global static variable
		
		//access to instance variable , create an object of class
		VariableExample o =new VariableExample();
		o.g1 =100;
		System.out.println("Global - instance variable : "+o.g1);
		
	}

}
