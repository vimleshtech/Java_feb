package day01;
import java.util.Scanner;

public class Stuudent {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter marks 1st sub");
		float sub1=sc.nextFloat();
		System.out.println("enter marks 2nd sub");
		float sub2=sc.nextFloat();
		System.out.println("enter marks 3rd sub");
		float sub3=sc.nextFloat();
		System.out.println("enter marks 4th sub");
		float sub4=sc.nextFloat();
		System.out.println("enter marks 5th sub");
		float sub5=sc.nextFloat();
		
		float avg;
		avg=((sub1+sub2+sub3+sub4+sub5)/5);
		
		System.out.println("Average: "+avg);
		
		if(avg>=60)
		{System.out.println("FIRST DIVISION");
		}
		

		else if (avg>=50 && avg<=59)
		{System.out.println("SeCOND DIVISION");
		}
		
		else if (avg>=40 && avg<=49)
		{System.out.println("THIRD DIVISION");
		}
		
		else 
		{System.out.println("FOURTH DIVISION");
		}
		

	}

}
