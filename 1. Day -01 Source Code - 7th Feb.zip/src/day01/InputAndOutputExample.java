package day01;

import java.util.Scanner;

public class InputAndOutputExample {

	public static void main(String[] args) {

			Scanner sc =new Scanner(System.in);
			String name;
			int rollno;
			int hs,es,cs,total;
			
			System.out.println("enter name :");
			name = sc.nextLine();
			
			System.out.println("enter rollno :");
			rollno = sc.nextInt();
			
			System.out.println("enter hs :");
			hs= sc.nextInt();
			
			System.out.println("enter es :");
			es= sc.nextInt();
			
			System.out.println("enter  cs:");
			cs= sc.nextInt();
			
			total = hs+es+cs;
			
			System.out.println("Name is : "+name);
			System.out.println("Total score is : "+total);
			
		

	}

}
