package day01;

import java.util.Scanner;

public class ConditionalExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc =new Scanner(System.in);
		String name;
		int rollno;
		int hs,es,cs,total;
		double avg =0;
		
		System.out.println("enter name :");
		name = sc.nextLine();
		
		System.out.println("enter rollno :");
		rollno = sc.nextInt();
		
		System.out.println("enter hs :");
		hs= sc.nextInt();
		
		System.out.println("enter es :");
		es= sc.nextInt();
		
		System.out.println("enter  cs:");
		cs= sc.nextInt();
		
		total = hs+es+cs;
		
		System.out.println("Name is : "+name);
		System.out.println("Total score is : "+total);
		
		avg = total/3;
		
		//print average
		if(avg>80)
		{
			System.out.println("A");
		}
		else if(avg>60)
		{
			System.out.println("B");
		}
		else if(avg>40)
		{
			System.out.println("C");
		}
		else
		{
			System.out.println("F");
		}
	}

}
