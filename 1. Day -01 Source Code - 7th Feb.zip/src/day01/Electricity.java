package day01;
import java.util.Scanner;

public class Electricity {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		float units;
		
		System.out.println("Enter total units");
		units=sc.nextFloat();
		if(units<=100)
		{
			float bill=(units*.40f)+50;
			System.out.println("BILL :"+bill);
		}
		
		else if (units>101 && units<299)
		{
			float bill=(units*.50f)+50;
			System.out.println("BILL :"+bill);
		}
		
		else 
		{
		 float bill=(units*.60f)+50;
		 System.out.println("BILL :"+bill);
	}

}
}
