package day01;

public class DatatypeExample {

	public static void main(String[] s)
	{
		
		byte b =111;
		short sh =3333;
		int i =22334333;
		long l = 3334444444445555l;
		
		float f  =433444.444f;
		double d = 33333.444;
		
		char c ='&';
		
		System.out.println(b);
		System.out.println(sh);
		System.out.println(i);
		System.out.println(l);
		System.out.println("float value :"+f);
		System.out.println("double value :"+d);
		
		
		boolean bo = true;
		System.out.println(bo);
		
		String name ="Raman sinha 25, Male";
		System.out.println("name is :"+name);
		
	}
}
