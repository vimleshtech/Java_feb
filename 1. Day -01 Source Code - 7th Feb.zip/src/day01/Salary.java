package day01;
import java.util.Scanner;
public class Salary {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	
	System.out.println("enter your salary");
	float salary=sc.nextFloat();
	double hra,da;
	
	
	if(salary>=5000 && salary<=10000)
	{
		hra = salary*.10;
		da = salary*.05;
		System.out.println("HRA  10% is  "+hra);
		System.out.println("DA 5% is "+da);
	}
		
		
	else if( salary>10000  && salary<15000)
	{
			hra = salary*.15;
			da = salary*.08;
			System.out.println("HRA  15% is  "+hra);
			System.out.println("DA 8% is "+da);
	}
	else
	{
		System.out.println("invalid input as per question");
	}
}
}

